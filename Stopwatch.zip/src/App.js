import Stopwatch from './component/Stopwatch';
import './index.css';

function App() {
  return (
    <>
<Stopwatch/>
    </>
  );
}

export default App;
